import type { ReactNode } from "react";
import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Layout } from "@/components/Layout";
import PageTransition from "@/components/PageTransition";
import { mlBackendService, type BackendIncident, type DashboardSummary, type RegisteredDevice } from "@/services/mlBackendService";
import { useAuth } from "@/store/authContext";

export default function OverviewPage() {
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [devices, setDevices] = useState<RegisteredDevice[]>([]);
  const [loadError, setLoadError] = useState("");
  const [trustingDevice, setTrustingDevice] = useState<string | null>(null);
  const { hasPermission } = useAuth();

  const refreshDashboard = useCallback(async () => {
    try {
      const [nextSummary, nextDevices] = await Promise.all([
        mlBackendService.getDashboardSummary(),
        mlBackendService.getDevices(),
      ]);
      setSummary(nextSummary);
      setDevices(nextDevices.devices);
      setLoadError("");
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : "Could not load live dashboard data.");
    }
  }, []);

  useEffect(() => {
    void refreshDashboard();
    const unsubscribe = mlBackendService.onThreatEvent((event) => {
      if (event?.type === "dashboard_update" || event?.type === "login_threat" || event?.type === "attack_chain") {
        void refreshDashboard();
      }
    });
    const intervalId = window.setInterval(() => void refreshDashboard(), 15000);
    return () => {
      unsubscribe();
      window.clearInterval(intervalId);
    };
  }, [refreshDashboard]);

  const trustDevice = async (deviceId: string) => {
    setTrustingDevice(deviceId);
    try {
      await mlBackendService.trustDevice(deviceId);
      await refreshDashboard();
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : "Unable to trust this device.");
    } finally {
      setTrustingDevice(null);
    }
  };

  const summaryIncidents = summary?.recent_incidents ?? [];
  const activeIncidents = summary?.active_incident_count ?? 0;
  const deviceCounts = summary?.device_counts;

  return (
    <PageTransition>
      <Layout>
        <div className="tn-content">
          <div className="kpi-grid">
            <KpiCard label="Average User Risk" value={summary ? summary.overall_risk.average.toFixed(1) : "—"} badge={{ text: summary ? `${summary.overall_risk.users_scored} scored` : "Loading", cls: "badge-medium" }} sub={summary ? `Maximum risk ${summary.overall_risk.maximum.toFixed(1)} / 100` : "Waiting for backend summary"} />
            <KpiCard label="Active Incidents" value={summary ? String(activeIncidents).padStart(2, "0") : "—"} badge={{ text: activeIncidents ? "Review" : "Clear", cls: activeIncidents ? "badge-high" : "badge-ok" }} sub="Open or investigating" />
            <KpiCard label="Trusted Devices" value={deviceCounts ? String(deviceCounts.trusted).padStart(2, "0") : "—"} badge={{ text: deviceCounts ? `${deviceCounts.total} total` : "Loading", cls: "badge-ok" }} sub="Manually approved fingerprints" />
            <KpiCard
              label="Devices Requiring Review"
              value={deviceCounts ? String(deviceCounts.unknown + deviceCounts.flagged).padStart(2, "0") : "—"}
              badge={{ text: deviceCounts?.flagged ? `${deviceCounts.flagged} flagged` : "Registry", cls: deviceCounts?.flagged ? "badge-critical" : "badge-medium" }}
              sub={deviceCounts ? `${deviceCounts.unknown} unknown · ${deviceCounts.flagged} flagged` : "Waiting for device registry"}
            />
            <Link to="/network-activity" className="overview-network-kpi-link" aria-label="View Network Activity anomalies">
              <KpiCard label="Network Anomalies" value={summary ? String(summary.network_anomalies).padStart(2, "0") : "—"} badge={{ text: "Live", cls: summary?.network_anomalies ? "badge-high" : "badge-ok" }} sub="Flagged request patterns · view activity →" />
            </Link>
          </div>

          {loadError && <div className="overview-load-error" role="status">Live backend data unavailable: {loadError}. Values below may be empty until the API reconnects.</div>}

          <div className="two-col overview-panels">
            <section className="panel panel-glow overview-panel">
              <div className="overview-panel-heading">
                <div className="heading" style={{ fontSize: 15, fontWeight: 700 }}>Illustrative Network Topology</div>
                <span className="badge badge-medium">Demo map</span>
              </div>
              <div className="bg-radial-red topology-map" role="img" aria-label="Illustrative network topology with one restricted asset and five connected nodes">
                <svg width="100%" height="100%" style={{ position: "absolute", inset: 0 }} aria-hidden="true">
                  <line x1="50%" y1="50%" x2="18%" y2="22%" stroke="rgba(255,43,77,0.35)" strokeWidth={1.5} />
                  <line x1="50%" y1="50%" x2="82%" y2="20%" stroke="rgba(255,255,255,0.12)" strokeWidth={1.5} />
                  <line x1="50%" y1="50%" x2="14%" y2="78%" stroke="rgba(255,255,255,0.12)" strokeWidth={1.5} />
                  <line x1="50%" y1="50%" x2="78%" y2="80%" stroke="rgba(255,176,32,0.35)" strokeWidth={1.5} />
                  <line x1="50%" y1="50%" x2="50%" y2="12%" stroke="rgba(255,255,255,0.12)" strokeWidth={1.5} />
                </svg>
                <div className="net-node topology-center" />
                <div className="net-node warn" style={{ left: "18%", top: "22%" }} />
                <div className="net-node ok" style={{ left: "82%", top: "20%" }} />
                <div className="net-node ok" style={{ left: "14%", top: "78%" }} />
                <div className="net-node warn" style={{ left: "78%", top: "80%" }} />
                <div className="net-node ok" style={{ left: "50%", top: "12%" }} />
                <div className="topology-label">RESTRICTED ASSET</div>
              </div>
            </section>

            <section className="panel panel-glow overview-panel">
              <div className="device-registry-heading">
                <div className="heading" style={{ fontSize: 15, fontWeight: 700 }}>Registered Devices</div>
                <span className="badge badge-medium">{deviceCounts?.total ?? 0} tracked</span>
              </div>
              <div className="device-registry-list">
                {devices.length === 0 ? (
                  <div className="device-empty">No login fingerprints registered yet.</div>
                ) : devices.slice(0, 6).map((device) => (
                  <div className="device-registry-row" key={device.device_id}>
                    <div className="device-registry-copy">
                      <strong>{device.label}</strong>
                      <span>{device.user_id} · seen {new Date(device.last_seen).toLocaleString()}</span>
                    </div>
                    <span className={`badge ${device.trust_status === "trusted" ? "badge-ok" : device.trust_status === "flagged" ? "badge-critical" : "badge-high"}`}>
                      {device.trust_status}
                    </span>
                    {device.trust_status === "unknown" && hasPermission("manage_devices") && (
                      <button className="device-trust-button" disabled={trustingDevice === device.device_id} onClick={() => void trustDevice(device.device_id)}>
                        {trustingDevice === device.device_id ? "…" : "Trust"}
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <div className="hr overview-csi-divider" />
              <div style={{ fontSize: 11.5, color: "var(--text-faint)", lineHeight: 1.6 }}>
                Browser/device fingerprints are registered as unknown until an administrator approves them. RF/CSI hardware monitoring is not connected.
              </div>
            </section>
          </div>

          <section className="overview-incidents">
            <div className="overview-section-heading">
              <div className="heading" style={{ fontSize: 16, fontWeight: 700 }}>Recent Incidents</div>
              <Link to="/incidents" style={{ fontSize: 13, fontWeight: 600 }}>View all →</Link>
            </div>
            <div className="panel panel-glow overview-table-wrap">
              <table className="tn-table">
                <thead><tr><th>ID</th><th>Summary</th><th>Severity</th><th>Agent</th><th>Status</th></tr></thead>
                <tbody>
                  {summaryIncidents.length ? summaryIncidents.map((incident) => <IncidentRow key={incident.id} incident={incident} />) : (
                    <tr><td colSpan={5} className="overview-empty-row">No backend incidents recorded yet.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      </Layout>
    </PageTransition>
  );
}

function KpiCard({ label, value, badge, sub }: { label: string; value: ReactNode; badge: { text: string; cls: string }; sub: string }) {
  return (
    <div className="panel panel-glow card-3d kpi-card">
      <div className="kpi-card-top"><div style={{ fontSize: 12, color: "var(--text-dim)" }}>{label}</div><span className={`badge ${badge.cls}`}>{badge.text}</span></div>
      <div className="heading glow-text kpi-card-value">{value}</div>
      <div style={{ fontSize: 12, color: "var(--text-faint)", marginTop: 4 }}>{sub}</div>
    </div>
  );
}

function IncidentRow({ incident }: { incident: BackendIncident }) {
  const severity = incident.severity.toLowerCase();
  const badge = severity === "critical" ? "badge-critical" : severity === "high" ? "badge-high" : "badge-medium";
  return (
    <tr>
      <td className="mono">{incident.id}</td>
      <td>{incident.title}</td>
      <td><span className={`badge ${badge}`}>{incident.severity}</span></td>
      <td>Risk Engine</td>
      <td><span className={`badge ${incident.status === "resolved" ? "badge-ok" : incident.status === "dismissed" ? "badge-medium" : "badge-high"}`}>{incident.status}</span></td>
    </tr>
  );
}
