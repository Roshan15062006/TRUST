"""Explainable fusion of the security signals currently collected by the demo."""

from __future__ import annotations

from typing import Any

from models.device_registry import list_devices
from models.network_monitor import network_score_for_user

# Weighted, bounded, and explicitly documented. Physical telemetry remains a stub.
WEIGHTS = {
    "behavioral": 0.30,
    "anomaly": 0.20,
    "classifier": 0.10,
    "device_trust": 0.20,
    "network": 0.20,
}
DEVICE_PENALTY = {"trusted": 0.0, "unknown": 50.0, "flagged": 100.0}
HIGH_RISK_THRESHOLD = 50.0

_latest_signals: dict[str, dict[str, Any]] = {}


def _clamp(value: float) -> float:
    return max(0.0, min(100.0, float(value)))


def _normalize(value: Any, *, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    if number != number or number in (float("inf"), float("-inf")):
        return default
    return max(0.0, min(1.0, number))


def calculate_centralized_risk(features: dict[str, Any]) -> float:
    """Compute the centralized risk formula required by the project spec."""
    if not isinstance(features, dict):
        raise ValueError("Risk features must be a dictionary.")
    csf = _normalize(features.get("csf"), default=0.0)
    network = _normalize(features.get("network"), default=0.0)
    device_untrusted = _normalize(features.get("deviceUntrusted"), default=0.0)
    geo_flag = _normalize(features.get("geoFlag"), default=0.0)
    score = 100.0 * (
        0.50 * csf + 0.20 * network + 0.20 * device_untrusted + 0.10 * geo_flag
    )
    return round(max(0.0, min(100.0, score)), 2)


def risk_tier_for_score(score: float) -> str:
    """Map risk score to the monitoring tier specified by the project."""
    normalized = max(0.0, min(100.0, float(score)))
    if normalized <= 30:
        return "Monitor"
    if normalized <= 60:
        return "MFA"
    if normalized <= 85:
        return "Restrict"
    return "Block"


def explain_centralized_risk(features: dict[str, Any]) -> dict[str, Any]:
    normalized = {
        "csf": _normalize(features.get("csf"), default=0.0),
        "network": _normalize(features.get("network"), default=0.0),
        "deviceUntrusted": _normalize(features.get("deviceUntrusted"), default=0.0),
        "geoFlag": _normalize(features.get("geoFlag"), default=0.0),
    }
    risk_score = calculate_centralized_risk(normalized)
    return {
        "inputs": normalized,
        "risk_score": risk_score,
        "tier": risk_tier_for_score(risk_score),
        "meaning": {
            "csf": "Behavioral/control signal severity normalized to 0-1.",
            "network": "Network anomaly risk normalized to 0-1.",
            "deviceUntrusted": "Device trust penalty for unrecognized or flagged devices normalized to 0-1.",
            "geoFlag": "Geo-location anomaly signal normalized to 0-1.",
        },
    }


def record_signals(
    user_id: str,
    *,
    behavioral_score: float,
    anomaly_score: float,
    classifier_label: str,
    classifier_confidence: float,
    device_id: str | None,
    device_trust_status: str,
) -> dict[str, Any]:
    """Store the latest observed signals and compute their fused risk result."""
    _latest_signals[user_id] = {
        "behavioral_score": _clamp(behavioral_score),
        "anomaly_score": _clamp(anomaly_score),
        "classifier_label": str(classifier_label),
        "classifier_confidence": _clamp(classifier_confidence),
        "device_id": device_id,
        "device_trust_status": device_trust_status,
    }
    return compute_risk(user_id)


def compute_risk(user_id: str) -> dict[str, Any]:
    """Compute score, level, and signal-by-signal contributions for a user."""
    signals = _latest_signals.get(user_id, {})
    devices = list_devices(user_id)
    selected_device = next((item for item in devices if item["device_id"] == signals.get("device_id")), None)
    trust_status = selected_device["trust_status"] if selected_device else signals.get("device_trust_status", "unknown")

    behavioral = _clamp(signals.get("behavioral_score", 0.0))
    anomaly = _clamp(signals.get("anomaly_score", 0.0))
    label = signals.get("classifier_label", "unknown")
    confidence = _clamp(signals.get("classifier_confidence", 0.0))
    classifier_signal = confidence if label.lower() not in {"benign", "unknown", ""} else 0.0
    device_penalty = DEVICE_PENALTY.get(trust_status, DEVICE_PENALTY["unknown"])
    network = network_score_for_user(user_id)

    contributions = {
        "behavioral": round(behavioral * WEIGHTS["behavioral"], 2),
        "anomaly": round(anomaly * WEIGHTS["anomaly"], 2),
        "classifier": round(classifier_signal * WEIGHTS["classifier"], 2),
        "device_trust": round(device_penalty * WEIGHTS["device_trust"], 2),
        "network": round(network * WEIGHTS["network"], 2),
    }
    score = round(_clamp(sum(contributions.values())), 2)
    level = "low" if score < 25 else "medium" if score < HIGH_RISK_THRESHOLD else "high" if score < 75 else "critical"

    return {
        "user_id": user_id,
        "score": score,
        "level": level,
        "thresholds": {"high": HIGH_RISK_THRESHOLD, "critical": 75.0},
        "breakdown": {
            "behavioral": {"score": behavioral, "weight": WEIGHTS["behavioral"], "contribution": contributions["behavioral"]},
            "isolation_forest": {"score": anomaly, "weight": WEIGHTS["anomaly"], "contribution": contributions["anomaly"]},
            "classifier": {"label": label, "confidence": confidence, "risk_score": classifier_signal, "weight": WEIGHTS["classifier"], "contribution": contributions["classifier"]},
            "device_trust": {"status": trust_status, "penalty": device_penalty, "weight": WEIGHTS["device_trust"], "contribution": contributions["device_trust"]},
            "network": {"score": network, "weight": WEIGHTS["network"], "contribution": contributions["network"], "note": "Based on flagged request patterns observed in the last 15 minutes."},
            "physical": {"score": None, "weight": 0.0, "contribution": 0.0, "note": "Physical RF/CSI monitoring signal is not implemented."},
        },
        "device_id": signals.get("device_id"),
    }


def list_known_users() -> list[str]:
    return sorted(_latest_signals)


def reset_risk_state() -> None:
    _latest_signals.clear()


def reset_user_risk(user_id: str) -> None:
    _latest_signals.pop(user_id, None)
