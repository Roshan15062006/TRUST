"""SQLite-backed persistence helpers for TrustNet demo data.

This intentionally uses the smallest local durable store that fits the project:
SQLite. It keeps the backend portable, requires no external service, and is
compatible with the in-memory architecture already in place.
"""

from __future__ import annotations

import json
import os
import sqlite3
from pathlib import Path
from typing import Any, Iterable

_DB_PATH = os.environ.get("TRUSTNET_DB_PATH") or str(Path(__file__).resolve().parents[1] / "data" / "trustnet.db")

def _ensure_parent_dir() -> None:
    Path(_DB_PATH).parent.mkdir(parents=True, exist_ok=True)


def get_db_connection() -> sqlite3.Connection:
    _ensure_parent_dir()
    connection = sqlite3.connect(_DB_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA foreign_keys=ON")
    return connection


def initialize_database() -> None:
    """Create the minimal tables required for durable event and risk data."""
    connection = get_db_connection()
    try:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS security_events (
                id TEXT PRIMARY KEY,
                timestamp TEXT NOT NULL,
                user_id TEXT,
                ip_address TEXT,
                device_fingerprint_hash TEXT,
                request_path TEXT NOT NULL,
                http_method TEXT NOT NULL,
                status_code INTEGER,
                session_id TEXT,
                event_category TEXT NOT NULL,
                risk_indicators TEXT,
                event_payload TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE INDEX IF NOT EXISTS idx_security_events_user_time
                ON security_events(user_id, timestamp);
            CREATE INDEX IF NOT EXISTS idx_security_events_ip_time
                ON security_events(ip_address, timestamp);
            CREATE INDEX IF NOT EXISTS idx_security_events_category
                ON security_events(event_category);

            CREATE TABLE IF NOT EXISTS risk_assessments (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                score REAL NOT NULL,
                tier TEXT NOT NULL,
                source TEXT NOT NULL,
                normalized_inputs TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE INDEX IF NOT EXISTS idx_risk_assessments_user
                ON risk_assessments(user_id, created_at);

            CREATE TABLE IF NOT EXISTS graph_entities (
                id TEXT PRIMARY KEY,
                entity_type TEXT NOT NULL,
                label TEXT NOT NULL,
                criticality INTEGER NOT NULL DEFAULT 1,
                risk_score REAL NOT NULL DEFAULT 0,
                metadata TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS graph_edges (
                id TEXT PRIMARY KEY,
                source_id TEXT NOT NULL,
                target_id TEXT NOT NULL,
                weight REAL NOT NULL,
                relation_type TEXT NOT NULL,
                reason TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(source_id) REFERENCES graph_entities(id),
                FOREIGN KEY(target_id) REFERENCES graph_entities(id)
            );

            CREATE TABLE IF NOT EXISTS incidents (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                severity TEXT NOT NULL,
                user_id TEXT,
                device_id TEXT,
                ip_address TEXT,
                risk_score REAL NOT NULL,
                status TEXT NOT NULL,
                reason TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                investigator_findings TEXT,
                response_action TEXT,
                approval_status TEXT,
                analyst_verdict TEXT,
                event_ids TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_incidents_status_time
                ON incidents(status, created_at);

            CREATE TABLE IF NOT EXISTS incident_events (
                incident_id TEXT NOT NULL,
                event_id TEXT NOT NULL,
                PRIMARY KEY (incident_id, event_id)
            );
            """
        )
        connection.commit()
    finally:
        connection.close()


def _sqlite_value(value: Any) -> str:
    return json.dumps(value, separators=(",", ":")) if value is not None else None


def _json_decode(value: Any) -> Any:
    if value is None:
        return None
    return json.loads(value)


def persist_rows(table: str, rows: Iterable[dict[str, Any]]) -> None:
    rows = list(rows)
    if not rows:
        return
    keys = list(rows[0].keys())
    connection = get_db_connection()
    try:
        placeholders = ", ".join("?" for _ in keys)
        assignments = ", ".join(f"{key} = excluded.{key}" for key in keys)
        insert_sql = f"INSERT INTO {table} ({', '.join(keys)}) VALUES ({placeholders}) ON CONFLICT(id) DO UPDATE SET {assignments}"
        connection.executemany(insert_sql, [tuple(row.get(key) for key in keys) for row in rows])
        connection.commit()
    finally:
        connection.close()
