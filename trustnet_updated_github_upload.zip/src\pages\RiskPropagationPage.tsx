import { useState } from "react";
import { Layout } from "@/components/Layout";
import { NetworkGraph } from "@/components/NetworkGraph";
import PageTransition from "@/components/PageTransition";
import { useSecurity } from "@/store/securityStore";

type SimulationMode = "live" | "whatif";

export default function RiskPropagationPage() {
  const [mode, setMode] = useState<SimulationMode>("live");
  const { nodes, edges, isAttackSimulated, attackChainRunning, liveThreatPhase } = useSecurity();
  const whatIf = mode === "whatif";
  const compromisedNodes = nodes.filter((node) => node.compromised);
  const attackPathEdges = edges.filter((edge) => edge.attackPath);
  const attackPathLabels = attackPathEdges.map((edge) => {
    const from = nodes.find((node) => node.id === edge.from)?.label ?? edge.from;
    const to = nodes.find((node) => node.id === edge.to)?.label ?? edge.to;
    return `${from} → ${to}`;
  });

  return (
    <PageTransition>
      <Layout>
        <div className="risk-page-topbar">
          <div>
            <div className="heading" style={{ fontSize: 20, fontWeight: 700 }}>Risk Propagation</div>
            <div style={{ fontSize: 12.5, color: "var(--text-faint)", marginTop: 2 }}>
              Attack-path simulation toward restricted assets
            </div>
          </div>
          <div className="risk-mode-buttons" role="group" aria-label="Simulation mode">
            <button type="button" className={`btn ${whatIf ? "btn-primary" : "btn-ghost"}`} aria-pressed={whatIf} onClick={() => setMode("whatif")}>
              What-if
            </button>
            <button type="button" className={`btn ${!whatIf ? "btn-primary" : "btn-ghost"}`} aria-pressed={!whatIf} onClick={() => setMode("live")}>
              <span className="dot pulse risk-live-dot" /> Live Simulation
            </button>
          </div>
        </div>

        <div className="tn-content risk-page-content">
          <div className="risk-page-grid">
            <section className="panel panel-glow risk-graph-panel">
              <div className="risk-panel-heading">
                <div className="heading" style={{ fontSize: 15, fontWeight: 700 }}>Propagation Graph</div>
                <span className={`badge ${isAttackSimulated ? "badge-critical" : whatIf ? "badge-medium" : "badge-ok"}`}>
                  {isAttackSimulated ? `${compromisedNodes.length} nodes compromised` : whatIf ? "What-if scenario" : "Monitoring network"}
                </span>
              </div>
                <div className={`graph-area bg-radial-red ${whatIf ? "risk-whatif" : "scan"}`}>
                  <NetworkGraph width={800} height={480} />
              </div>
              <div className="risk-legend">
                <span><span className="dot" style={{ background: "#2bd97c" }} /> Low</span>
                <span><span className="dot" style={{ background: "#9a9ba3" }} /> Normal</span>
                <span><span className="dot" style={{ background: "#ffb020" }} /> Elevated</span>
                <span><span className="dot" style={{ background: "#ff2b4d" }} /> Critical path</span>
              </div>
              {isAttackSimulated && compromisedNodes.length > 0 ? (
                <div className="risk-affected-panel" aria-live="polite">
                  <div className="risk-affected-heading">
                    <span className="dot pulse" style={{ background: "#ff2b4d" }} />
                    AFFECTED DEVICES / SYSTEMS ({compromisedNodes.length})
                    {attackChainRunning && <span className="risk-phase">{liveThreatPhase.toUpperCase()} IN PROGRESS</span>}
                  </div>
                  <div className="risk-affected-list">
                    {compromisedNodes.map((node) => (
                      <div className="risk-affected-device" key={node.id}>
                        <span className="risk-device-type">{node.type}</span>
                        <strong>{node.label}</strong>
                        <span className="risk-device-score">RISK {node.propagationRisk}%</span>
                      </div>
                    ))}
                  </div>
                  {attackPathLabels.length > 0 && (
                    <div className="risk-path-edges">
                      <span className="risk-device-type">ACTIVE ATTACK LINKS</span>
                      {attackPathLabels.map((path) => <span key={path}>{path}</span>)}
                    </div>
                  )}
                </div>
              ) : (
                <div className="risk-idle-hint">Use <strong>SIMULATE ATTACK</strong> in the top bar to animate affected devices and active attack links here.</div>
              )}
            </section>

            <div className="risk-side-panels">
              <section className="panel panel-glow risk-gauge-panel">
                <div className="heading" style={{ fontSize: 15, fontWeight: 700, marginBottom: 12 }}>Propagation Risk Score</div>
                <div className="gauge-wrap">
                  <svg viewBox="0 0 220 120" width="220" height="120" aria-hidden="true">
                    <path d="M10,110 A100,100 0 0,1 210,110" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={14} strokeLinecap="round" />
                    <path d="M10,110 A100,100 0 0,1 168,32" fill="none" stroke={whatIf ? "#ffb020" : isAttackSimulated ? "#ff2b4d" : "#2bd97c"} strokeWidth={14} strokeLinecap="round" />
                  </svg>
                  <div className="risk-gauge-value">
                    <div className="heading glow-text" style={{ fontSize: 30, fontWeight: 700 }}>{whatIf ? "61" : isAttackSimulated ? "94" : "18"}</div>
                    <div style={{ fontSize: 11, color: "var(--text-faint)" }}>of 100 · {whatIf ? "Elevated" : isAttackSimulated ? "Critical" : "Safe"}</div>
                  </div>
                </div>
                <div className="risk-gauge-caption">
                  {whatIf ? "What-if estimate with the suspected entry point isolated" : isAttackSimulated ? "Score escalates with the active simulated attack" : "No attack currently propagating through the network"}
                </div>
              </section>

              <section className="panel panel-glow risk-path-panel">
                <div className="heading" style={{ fontSize: 15, fontWeight: 700, marginBottom: 6 }}>Shortest Path to Asset</div>
                {(isAttackSimulated && compromisedNodes.length > 0 ? compromisedNodes : nodes.slice(0, 3)).map((node, index) => {
                  const nextNode = compromisedNodes[index + 1];
                  const linkedNext = nextNode && attackPathEdges.some((edge) =>
                    (edge.from === node.id && edge.to === nextNode.id) || (edge.to === node.id && edge.from === nextNode.id)
                  );
                  return (
                    <div key={node.id} className="path-step">
                      <div className="step-num">{index + 1}</div>
                      <div>
                        <div style={{ fontSize: 13, color: "#d7d8dd", fontWeight: 600 }}>{node.label}</div>
                        <div style={{ fontSize: 11.5, color: "var(--text-faint)" }}>
                          {whatIf && index === 1 ? "What-if: this connection is isolated" : isAttackSimulated ? linkedNext && nextNode ? `Attack path continues to ${nextNode.label}` : `Compromised · risk ${node.propagationRisk}%` : `Baseline node · propagation risk ${node.propagationRisk}%`}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </section>
            </div>
          </div>
        </div>
      </Layout>
    </PageTransition>
  );
}
