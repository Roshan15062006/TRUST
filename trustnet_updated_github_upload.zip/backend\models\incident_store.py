"""In-memory incident lifecycle store for the single-process demo."""

from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

_INCIDENTS: dict[str, dict[str, Any]] = {}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def maybe_create_risk_incident(risk: dict[str, Any], *, evidence: list[str] | None = None) -> dict[str, Any] | None:
    """Create/update one open high-risk incident per user and device."""
    if risk["score"] < 50:
        return None
    user_id = risk["user_id"]
    device_id = risk.get("device_id")
    for incident in _INCIDENTS.values():
        if (incident["user_id"] == user_id and incident.get("device_id") == device_id
                and incident["status"] in {"open", "investigating"}):
            incident["risk_score"] = risk["score"]
            incident["severity"] = risk["level"].title()
            incident["evidence"] = list(dict.fromkeys(incident["evidence"] + (evidence or [])))
            incident["updated_at"] = _now()
            return dict(incident)

    incident_id = f"INC-{uuid4().hex[:10].upper()}"
    incident = {
        "id": incident_id,
        "title": f"High fused risk for {user_id}",
        "severity": risk["level"].title(),
        "user_id": user_id,
        "device_id": device_id,
        "risk_score": risk["score"],
        "status": "open",
        "created_at": _now(),
        "updated_at": _now(),
        "evidence": evidence or [],
        "response_action": None,
        "risk_breakdown": risk["breakdown"],
    }
    _INCIDENTS[incident_id] = incident
    return dict(incident)


def list_incidents(*, status: str | None = None) -> list[dict[str, Any]]:
    if status == "active":
        incidents = [item for item in _INCIDENTS.values() if item["status"] in {"open", "investigating"}]
    else:
        incidents = [item for item in _INCIDENTS.values() if status is None or item["status"] == status]
    return sorted((dict(item) for item in incidents), key=lambda item: item["created_at"], reverse=True)


def get_incident(incident_id: str) -> dict[str, Any] | None:
    incident = _INCIDENTS.get(incident_id)
    return dict(incident) if incident else None


def transition_incident(incident_id: str, status: str, response_action: str | None = None) -> dict[str, Any] | None:
    if status not in {"open", "investigating", "resolved", "dismissed"}:
        raise ValueError("Unsupported incident status")
    incident = _INCIDENTS.get(incident_id)
    if incident is None:
        return None
    incident["status"] = status
    incident["updated_at"] = _now()
    if response_action is not None:
        incident["response_action"] = response_action
    return dict(incident)


def reset_incidents() -> None:
    _INCIDENTS.clear()
