import { useState } from "react";
import { Layout } from "@/components/Layout";
import PageTransition from "@/components/PageTransition";

const HEATMAP_OPACITIES = [
  0.08, 0.06, 0.05, 0.05, 0.1, 0.18, 0.32, 0.42, 0.5, 0.6, 0.46, 0.3,
  0.22, 0.18, 0.2, 0.28, 0.4, 0.55, 0.4, 0.2, 0.1, 0.07, 0.05, 0.04,
];
const HEATMAP_WARN_IDX = [17, 18];

const ENTITIES = [
  { name: "HR-WKS-12", pct: 88, score: "8.8", color: "linear-gradient(90deg,#ff2b4d,#ff5470)", scoreColor: "#ff5470" },
  { name: "ESP32-NODE-C", pct: 71, score: "7.1", color: "linear-gradient(90deg,#ff2b4d,#ff5470)", scoreColor: "#ff5470" },
  { name: "FIN-SVC-02", pct: 54, score: "5.4", color: "#ffb020", scoreColor: "#ffb020" },
  { name: "LAB-GW-01", pct: 38, score: "3.8", color: "#ffb020", scoreColor: "#ffb020" },
  { name: "DEV-LAPTOP-9", pct: 16, score: "1.6", color: "#2bd97c", scoreColor: "#2bd97c" },
];

const WEEK_BARS = [30, 38, 34, 46, 42, 91, 78, 50];
const WEEK_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun", "Today"];
const RANGES = ["24H", "7D", "30D"] as const;

type Range = (typeof RANGES)[number];

export default function BehaviorAnalyticsPage() {
  const [range, setRange] = useState<Range>("7D");

  return (
    <PageTransition>
      <Layout>
        <div className="tn-content behavior-page">
          <div className="behavior-page-heading">
            <div>
              <div className="heading" style={{ fontSize: 20, fontWeight: 700 }}>Behavior Analytics</div>
              <div style={{ fontSize: 12.5, color: "var(--text-faint)", marginTop: 2 }}>
                Anomaly scoring across 8 monitored entities
              </div>
            </div>
            <div className="behavior-range-tabs" role="group" aria-label="Analytics time range">
              {RANGES.map((item) => (
                <button
                  key={item}
                  type="button"
                  className={`chip${range === item ? " active" : ""}`}
                  aria-pressed={range === item}
                  onClick={() => setRange(item)}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <section className="panel panel-glow behavior-timeline">
            <div className="behavior-panel-heading">
              <div className="heading" style={{ fontSize: 15, fontWeight: 700 }}>Anomaly Score Timeline</div>
              <div className="behavior-legend">
                <span><span className="dot" style={{ background: "#ff2b4d" }} /> Anomaly score</span>
                <span><span className="dot" style={{ background: "#5c5d66" }} /> Baseline</span>
              </div>
            </div>
            <svg viewBox="0 0 1000 220" className="behavior-chart" role="img" aria-label={`Anomaly score timeline for ${range}`}>
              <defs>
                <linearGradient id="behaviorFillGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#ff2b4d" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#ff2b4d" stopOpacity={0} />
                </linearGradient>
              </defs>
              <line x1="0" y1="55" x2="1000" y2="55" stroke="rgba(255,255,255,0.06)" />
              <line x1="0" y1="110" x2="1000" y2="110" stroke="rgba(255,255,255,0.06)" />
              <line x1="0" y1="165" x2="1000" y2="165" stroke="rgba(255,255,255,0.06)" />
              <polyline
                points="0,160 80,155 160,150 240,158 320,140 400,60 480,30 560,70 640,120 720,100 800,130 880,110 1000,100"
                fill="none" stroke="#5c5d66" strokeWidth={1.5} strokeDasharray="4 4"
              />
              <polygon
                points="0,180 80,172 160,168 240,175 320,150 400,48 480,20 560,55 640,150 720,95 800,160 880,120 1000,90 1000,220 0,220"
                fill="url(#behaviorFillGrad)"
              />
              <polyline
                points="0,180 80,172 160,168 240,175 320,150 400,48 480,20 560,55 640,150 720,95 800,160 880,120 1000,90"
                fill="none" stroke="#ff5470" strokeWidth={2.5}
              />
              <circle cx={480} cy={20} r={5} fill="#ff2b4d" />
              <text x={492} y={16} fill="#ff5470" fontSize={11} fontFamily="'JetBrains Mono', monospace">Investigator triggered</text>
            </svg>
          </section>

          <div className="two-col behavior-detail-grid">
            <section className="panel panel-glow behavior-panel">
              <div className="heading behavior-panel-title">Access Heatmap — HR-WKS-12</div>
              <div className="heat-grid">
                {HEATMAP_OPACITIES.map((opacity, index) => (
                  <div
                    key={index}
                    className="heat-cell"
                    aria-label={`Hour ${index}: ${HEATMAP_WARN_IDX.includes(index) ? "elevated" : "normal"} activity`}
                    style={{ background: `rgba(255,${HEATMAP_WARN_IDX.includes(index) ? "176,32" : "43,77"},${opacity})` }}
                  />
                ))}
              </div>
              <div className="behavior-axis-labels"><span>00:00</span><span>06:00</span><span>12:00</span><span>18:00</span><span>23:59</span></div>
              <div className="behavior-explanation">
                Access spikes at 20:00–22:00 fall well outside this entity&apos;s 30-day baseline window — flagged by the Isolation Forest model and queued for investigation.
              </div>
            </section>

            <section className="panel panel-glow behavior-panel">
              <div className="heading behavior-panel-title">Top Anomalous Entities</div>
              <div className="behavior-entities">
                {ENTITIES.map((entity) => (
                  <div key={entity.name} className="entity-row">
                    <span className="behavior-entity-name">{entity.name}</span>
                    <div className="bar-track"><div className="bar-fill" style={{ width: `${entity.pct}%`, background: entity.color }} /></div>
                    <span className="mono behavior-entity-score" style={{ color: entity.scoreColor }}>{entity.score}</span>
                  </div>
                ))}
              </div>
            </section>
          </div>

          <section className="panel panel-glow behavior-panel behavior-drift">
            <div className="heading behavior-panel-title">Feature Drift — Session Velocity vs. Baseline</div>
            <div className="behavior-bars" role="img" aria-label="Session velocity over the last week">
              {WEEK_BARS.map((height, index) => {
                const anomalous = height > 70;
                return (
                  <div
                    key={WEEK_LABELS[index]}
                    className="behavior-bar"
                    style={{
                      height: `${height}%`,
                      background: anomalous ? "linear-gradient(180deg,#ff2b4d,#8f0f26)" : "linear-gradient(180deg,#2a2c33,#1a1c21)",
                      boxShadow: anomalous ? "0 0 24px -4px rgba(255,43,77,0.55)" : "none",
                    }}
                  />
                );
              })}
            </div>
            <div className="behavior-axis-labels">{WEEK_LABELS.map((label) => <span key={label}>{label}</span>)}</div>
          </section>
        </div>
      </Layout>
    </PageTransition>
  );
}
