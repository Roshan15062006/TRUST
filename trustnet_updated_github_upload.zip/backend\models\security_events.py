"""Security event validation and persistence helpers.

These functions validate event payloads and persist them to the SQLite database
for the project's demo deployment. The public interfaces intentionally mirror
existing usage patterns while storing durable records.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from models.database import get_db_connection, initialize_database

_RETENTION_DAYS = 90


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def validate_security_event(event: dict[str, Any]) -> dict[str, Any]:
    """Validate a security event before storing it.

    Strict validation keeps the log safe and compact. Passwords, tokens and other
    secrets are never accepted or persisted.
    """
    if not isinstance(event, dict):
        raise ValueError("Event payload must be a dictionary.")

    request_path = str(event.get("request_path") or "").strip()
    http_method = str(event.get("http_method") or "").strip().upper()
    if not request_path or not request_path.startswith("/"):
        raise ValueError("request_path must be a non-empty path beginning with '/'.")
    if http_method not in {"GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"}:
        raise ValueError("http_method is invalid.")

    user_id = event.get("user_id")
    if user_id is not None and not isinstance(user_id, str):
        raise ValueError("user_id must be a string when provided.")

    ip_address = event.get("ip_address")
    if ip_address is not None and not isinstance(ip_address, str):
        raise ValueError("ip_address must be a string when provided.")

    fingerprint_hash = event.get("device_fingerprint_hash")
    if fingerprint_hash is not None and not isinstance(fingerprint_hash, str):
        raise ValueError("device_fingerprint_hash must be a string when provided.")

    session_id = event.get("session_id")
    if session_id is not None and not isinstance(session_id, str):
        raise ValueError("session_id must be a string when provided.")

    event_category = str(event.get("event_category") or "").strip()
    if not event_category:
        raise ValueError("event_category is required.")

    risk_indicators = event.get("risk_indicators") or []
    if not isinstance(risk_indicators, list):
        raise ValueError("risk_indicators must be a list.")
    risk_indicators = [str(item) for item in risk_indicators if item is not None]

    status_code = event.get("status_code")
    if status_code is not None:
        try:
            status_code = int(status_code)
        except (TypeError, ValueError) as exc:
            raise ValueError("status_code must be an integer when present.") from exc
        if status_code < 100 or status_code > 599:
            raise ValueError("status_code must be between 100 and 599.")

    result = {
        "id": str(event.get("id") or f"EVT-{uuid4().hex[:12].upper()}"),
        "timestamp": str(event.get("timestamp") or _utc_now()),
        "user_id": user_id,
        "ip_address": ip_address,
        "device_fingerprint_hash": fingerprint_hash,
        "request_path": request_path,
        "http_method": http_method,
        "status_code": status_code,
        "session_id": session_id,
        "event_category": event_category,
        "risk_indicators": risk_indicators,
        "event_payload": event.get("event_payload") or {},
    }
    return {"valid": True, "event": result}


def persist_security_event(event: dict[str, Any]) -> dict[str, Any]:
    """Persist a validated security event into SQLite."""
    validate_result = validate_security_event(event)
    payload = validate_result["event"]
    if not payload.get("id"):
        payload["id"] = f"EVT-{uuid4().hex[:12].upper()}"
    if not payload.get("timestamp"):
        payload["timestamp"] = _utc_now()
    connection = get_db_connection()
    try:
        connection.execute(
            """
            INSERT OR REPLACE INTO security_events (
                id, timestamp, user_id, ip_address, device_fingerprint_hash,
                request_path, http_method, status_code, session_id,
                event_category, risk_indicators, event_payload
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                payload["id"],
                payload["timestamp"],
                payload["user_id"],
                payload["ip_address"],
                payload["device_fingerprint_hash"],
                payload["request_path"],
                payload["http_method"],
                payload["status_code"],
                payload["session_id"],
                payload["event_category"],
                repr(payload["risk_indicators"]),
                repr(payload["event_payload"]),
            ),
        )
        connection.commit()
    finally:
        connection.close()
    return payload


def list_security_events(*, user_id: str | None = None, ip_address: str | None = None, limit: int = 200) -> list[dict[str, Any]]:
    initialize_database()
    query = "SELECT * FROM security_events WHERE 1=1"
    params: list[Any] = []
    if user_id:
        query += " AND user_id = ?"
        params.append(user_id)
    if ip_address:
        query += " AND ip_address = ?"
        params.append(ip_address)
    query += " ORDER BY timestamp DESC LIMIT ?"
    params.append(limit)
    connection = get_db_connection()
    try:
        rows = connection.execute(query, params).fetchall()
    finally:
        connection.close()
    return [dict(row) for row in rows]


def get_event_retention_days() -> int:
    return int(os.environ.get("TRUSTNET_EVENT_RETENTION_DAYS", str(_RETENTION_DAYS)))


def prune_old_events() -> int:
    """Delete expired events, returning the number of removed rows."""
    days = get_event_retention_days()
    cutoff = (datetime.now(timezone.utc).timestamp() - (days * 86400))
    connection = get_db_connection()
    try:
        cursor = connection.execute(
            "DELETE FROM security_events WHERE datetime(timestamp) < datetime(?, 'unixepoch')",
            (cutoff,),
        )
        connection.commit()
        return cursor.rowcount
    finally:
        connection.close()
