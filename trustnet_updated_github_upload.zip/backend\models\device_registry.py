"""In-memory device registry used by the single-process demo backend."""

from datetime import datetime, timezone
import hashlib
from typing import Any

from models.login_detector import hash_fingerprint

_DEVICES: dict[str, dict[str, Any]] = {}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _label(fingerprint: dict[str, Any]) -> str:
    platform = str(fingerprint.get("platform") or "Unknown platform")
    user_agent = str(fingerprint.get("userAgent") or "")
    browser = "Browser"
    for marker, name in (("Edg/", "Edge"), ("Firefox/", "Firefox"), ("Chrome/", "Chrome"), ("Safari/", "Safari")):
        if marker in user_agent:
            browser = name
            break
    return f"{browser} on {platform}"


def register_login_device(user_id: str, fingerprint: dict[str, Any], *, first_login: bool = False) -> dict[str, Any]:
    """Record a fingerprint on login without automatically trusting new devices."""
    now = _utc_now()
    fingerprint_hash = hash_fingerprint(fingerprint)
    device_id = "dev-" + hashlib.sha256(f"{user_id}:{fingerprint_hash}".encode()).hexdigest()[:16]
    key = f"{user_id}:{device_id}"
    existing = _DEVICES.get(key)
    if existing is None:
        device = {
            "device_id": device_id,
            "user_id": user_id,
            "fingerprint_hash": fingerprint_hash,
            "first_seen": now,
            "last_seen": now,
            "trust_status": "unknown",
            "label": _label(fingerprint),
            "last_login_first_for_user": first_login,
            "quarantined": False,
        }
        _DEVICES[key] = device
        return dict(device)

    existing["last_seen"] = now
    existing["label"] = _label(fingerprint)
    existing["last_login_first_for_user"] = first_login
    return dict(existing)


def list_devices(user_id: str | None = None) -> list[dict[str, Any]]:
    devices = [device for device in _DEVICES.values() if user_id is None or device["user_id"] == user_id]
    return sorted((dict(device) for device in devices), key=lambda device: device["last_seen"], reverse=True)


def get_device(device_id: str) -> dict[str, Any] | None:
    for device in _DEVICES.values():
        if device["device_id"] == device_id:
            return dict(device)
    return None


def set_device_status(device_id: str, trust_status: str, *, quarantined: bool | None = None) -> dict[str, Any] | None:
    if trust_status not in {"trusted", "unknown", "flagged"}:
        raise ValueError("trust_status must be trusted, unknown, or flagged")
    for device in _DEVICES.values():
        if device["device_id"] == device_id:
            device["trust_status"] = trust_status
            if quarantined is not None:
                device["quarantined"] = quarantined
            return dict(device)
    return None


def reset_devices() -> None:
    _DEVICES.clear()


def reset_user_devices(user_id: str) -> None:
    for key in [key for key, device in _DEVICES.items() if device["user_id"] == user_id]:
        del _DEVICES[key]
