import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import "./styles/trustnet-theme.css";

createRoot(document.getElementById("root")!).render(<App />);
