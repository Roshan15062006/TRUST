# Project status moved

For the canonical project status, implementation scope, verification evidence and open release gates, see [`docs/STATUS.md`](docs/STATUS.md) and [`docs/REMAINING_RELEASE_GATES.md`](docs/REMAINING_RELEASE_GATES.md).
