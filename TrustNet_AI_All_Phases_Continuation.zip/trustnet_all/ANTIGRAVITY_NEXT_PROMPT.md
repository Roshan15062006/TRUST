# Status moved

The canonical implementation and verification status is maintained in [`docs/STATUS.md`](docs/STATUS.md). Do not use this legacy file as a source of release claims.
