# TrustNet AI — implementation status

Last updated: 2026-10-19. This is demonstration software using synthetic data. A green test suite is not proof of real-world detection accuracy or production readiness.

## Newly implemented in this update

- Analyst verdicts now update a persisted per-user behavior EMA using `new = (1 - alpha) * old + alpha * observed`, with demo `alpha=0.2`, baseline version increments, and sample counts. A confirmed true-positive label adds known-bad device/IP indicators when those values exist. The verdict response includes profile before/after evidence. This is a transparent demo signal and does not retrain an ML model or yet feed the indicator list back into risk scoring.
- Added `backend/test_behavior_learning_profile.py` covering false-positive EMA reduction, baseline versioning, true-positive indicator recording, and alpha validation.


- Response agent now applies risk-band decisions for non-malicious cases: 31–60 proposes step-up MFA; 61–85 proposes a human-approved, 30-minute read-only restriction when no device is available; 86–100 proposes a human-approved temporary block when no device is available. Existing high-confidence malicious-device containment remains higher priority. This is a partial risk ladder, not full parity for every combination of verdict, device, and risk score.
- Added `backend/test_response_risk_ladder.py` with five tests covering medium risk, read-only restriction proposal, critical-risk block proposal, low-risk monitoring, and high-confidence malicious-device containment.

- `GET /api/hr/records`: role-policy protected synthetic HR rows; every attempt records a `protected_asset_access` security event with user, IP, device, role, asset, and allow/deny outcome.
- `GET /api/files/export`: role-policy protected synthetic export metadata only; does not expose file contents and audits every attempt.
- Restricted-session middleware treats both new paths as sensitive, so an active read-only restriction denies them.
- Added endpoint tests for authorized and unauthorized access and synthetic-only response content.

## Verification run in this update

- `python -m compileall -q backend` — PASS.
- `cd backend && python -m unittest test_response_risk_ladder test_agents test_approval_core -q` — PASS in the previous update (62 tests).
- `cd backend && python -m unittest test_behavior_learning_profile test_response_risk_ladder test_approval_core -q` — PASS after the EMA changes (17 tests).
- `cd backend && python -m unittest test_agents.AgentPipelineTests.test_synthetic_hr_records_are_authorized_and_marked_synthetic test_agents.AgentPipelineTests.test_synthetic_file_export_returns_metadata_not_file_contents -v` — PASS, 2 tests.
- `cd backend && python -m unittest test_agents -q` before adding the two tests — PASS, 45 tests. The two new tests passed separately afterward. A full `python -m unittest discover -p 'test_*.py' -q` run was attempted after this change but exceeded the 180-second execution limit in this environment; it did not produce a final pass/fail summary, so the combined suite is **unverified**.

## Still open / not verified

- Full risk ladder (`MONITOR` 0–30, step-up MFA 31–60, `RESTRICT_SESSION` 61–85, temporary block 86–100) is only partially wired: elevated and critical bands currently use restrictions/blocks when no device is available and the verdict is not `likely_malicious`; all verdict/device combinations need policy review and tests.
- EMA profile persistence, baseline versioning, and profile before/after evidence are implemented for demo verdicts. Known-bad device/IP indicators are recorded but not yet consumed by the risk engine; trusted-device-on-false-positive selection and a stored-session score replay UI remain incomplete.
- WebSocket SOC-room role isolation and complete health/degraded-mode reporting require verification.
- Frontend lint, mock-data removal, route lazy-loading, bundle splitting, and the 25+ test target are not verified as passing.
- Reproducible multi-seed evaluation, full end-to-end demo proof, three stable backend runs, coverage targets, dependency audits, CI, and Docker runtime remain unverified.
- LSTM and CSI hardware are not claimed as implemented. Evaluation data and model metrics are synthetic and must not be represented as real-world accuracy.

## Release position

**Not release-complete.** The two protected-resource endpoints are implemented and tested; the remaining items above must not be described as complete until implemented and verified with actual command output.

## Latest implementation update — analyst-confirmed device indicators

- Added `known_bad_indicators()` and `is_known_bad_indicator()` helpers to the feedback-learning module.
- Connected analyst-confirmed device indicators to `compute_risk()`: a listed device is treated as `flagged` for the device-trust contribution even if the incoming signal says `trusted`.
- Risk output now exposes `known_bad_indicators.device_flagged` and an explainable reason when the indicator contributed.
- Added isolated regression tests proving confirmed listed devices receive the flagged-device penalty and unlisted devices do not.
- Verified: `python -m compileall -q backend`; `python -m unittest test_known_bad_scoring test_behavior_learning_profile test_risk_policy_ingest -q` (24 tests passed).
- Scope note (superseded by the 2026-10-19 IP request-flow update below): device IDs and IP indicators are connected to live scoring where call sites provide them. Other ingestion paths still require end-to-end verification. The test model output in the existing ML startup logs is synthetic-data performance, not real-world validation. Frontend, Docker, dependency audit, and full end-to-end release checks remain unverified.

## Incident learning replay API update (2026-10-19)
- Added `GET /api/incidents/{incident_id}/learning-replay` behind `view_dashboard` permission.
- Returns persisted before/after score observations from analyst verdict feedback, score delta, policy version, and current behavior profile when available.
- Returns an explicit `no_feedback_effect` state when no persisted score comparison exists; it does not fabricate before/after scores.
- Replay evidence explicitly states that this is a bounded rule adjustment and not ML model retraining or causal proof of accuracy improvement.
- Targeted verification: `test_learning_replay` and `test_behavior_profiles` passed (5 tests); Python compilation passed.
- Full API/frontend/release verification remains outstanding.

## Latest implementation update — incident learning replay UI

- Added an authenticated frontend service method for `GET /api/incidents/{incident_id}/learning-replay`.
- Added an Incident Response Center panel that loads real backend incidents, lets an analyst select one, and displays persisted before/after scores, delta, verdict, policy version, and the backend's evidence disclaimer.
- The UI displays `N/A` when score values are absent; it does not manufacture before/after values. Mock incident cards remain separate from backend replay evidence.
- Verification in this environment: `python -m compileall -q backend` passed; targeted backend learning/replay tests passed (7 tests). Frontend build/typecheck/lint were not run because `node_modules` is not installed and dependency installation has not been verified.

## Latest implementation update — analyst-confirmed IP scoring

- Persisted the latest observed source IP in `risk_signals` with an additive SQLite migration.
- `record_signals(..., ip_address=...)` carries the observed IP into live risk scoring.
- Analyst-confirmed known-bad IPs add a bounded 25-point contribution after weighted fusion; the response includes `known_bad_indicators.ip_flagged`, `adjustments.known_bad_ip_points`, and a reason string.
- Added regression coverage for flagged/unlisted IPs and database reload persistence.
- Verification run: Python compilation passed; targeted learning/profile/replay/scoring tests: 9 passed.
- IP indicators are canonicalized with Python `ipaddress` before storage/lookup, including compressed IPv6 and IPv4-mapped IPv6 forms. Invalid/legacy values remain exact strings; this does not perform CIDR/range matching or external reputation lookups. Call sites must supply the observed IP to `record_signals` for it to be scored.


### Observed client IP passed into scoring (2026-10-19)
- The real login detection route now passes the transport peer IP (`request.client.host` via `_client_ip`) into `record_signals`, so the canonicalized known-bad IP indicator can affect the login risk score.
- The simulated threat ingestion route also supplies its transport peer IP. Arbitrary `X-Forwarded-For` values are deliberately not trusted; deployments behind a proxy must configure a trusted-proxy strategy before using forwarded IP headers.
- Verification: `python -m compileall -q backend` passed; selected backend security, learning/replay, behavior-profile and risk-ingest suites passed (84 tests). This is not a full project test run. Frontend build, Docker, dependency audit, and full E2E remain unverified.

## Synthetic end-to-end IP risk regression (2026-10-19)
- Added `backend/test_e2e_ip_pipeline.py` to exercise analyst-confirmed indicator learning, canonical IPv6 matching, persisted live risk scoring, incident creation/evidence, investigation/response generation, and audit-chain verification using an isolated temporary SQLite database.
- Includes a negative control proving an unlisted documentation-range IP does not receive known-bad IP points.
- Verification: `python -m compileall -q backend` passed; `cd backend && python -m unittest test_e2e_ip_pipeline test_known_bad_scoring test_learning_replay -q` passed (10 tests).
- Inputs are synthetic fixtures; this is an integration regression, not real-world detection-accuracy evidence. Full backend/frontend/release gates remain open.


## Verification runner update — latest regression coverage (2026-10-19)
- Updated `scripts/verify_all.sh` to run the newer IP end-to-end, known-bad scoring, learning replay, behavior profile, and response-risk-ladder tests as an explicit verification step. This prevents those tests from being silently omitted by the older named test list.
- Verification attempted in this environment: `python -m unittest discover -v` did not finish within the execution time limit, so no complete-suite pass/fail result is claimed. The frontend dependency installation (`npm ci --ignore-scripts --no-audit --no-fund`) also timed out; frontend build, lint, and Vitest remain unverified.
- Run `bash scripts/verify_all.sh` on a network-enabled environment to execute the documented release gates and inspect `verification-report.txt`.


## Analytics mock-data isolation update (2026-10-19)
- Replaced the legacy `src/pages/BehaviorAnalytics.tsx` demo-chart implementation with a compatibility re-export of `BehaviorAnalyticsPage`, which derives analytics from persisted backend request events.
- This prevents any route or component still importing the legacy module from silently displaying hard-coded sample locations, generated trend values, or simulated attack deviations as analytics.
- The active `/behavior`, `/behavior-analytics`, and `/behavior-live` routes already point to the persisted-event page. Empty backend results remain explicitly empty; they are not backfilled with synthetic values.
- Verification: source-level import inspection and Python backend compilation are run for this update. Frontend build/lint/Vitest remain unverified unless dependencies install and commands pass.

## Analytics time-window regression coverage (2026-10-19)
- Extracted the persisted-event time-window filter into `src/lib/behaviorAnalytics.ts` so timestamp handling is isolated and testable.
- Added `src/test/behaviorAnalytics.test.ts` covering inclusive start/end boundaries, invalid timestamps, stale/future events, and invalid/reversed windows.
- `BehaviorAnalyticsPage` now uses the shared filter helper; invalid timestamps cannot enter the chart buckets.
- Verification: Python compilation and shell syntax checks passed; selected backend regression suites passed (9 tests). `npm ci` timed out in this environment, so the new Vitest tests and frontend build/lint are added but not yet executed.

## CI regression coverage update (2026-10-19)
- Added an explicit CI step for the newer IP end-to-end, known-bad scoring, learning replay, behavior profile, and response risk-ladder regression suites.
- Enabled npm dependency caching in the frontend and dependency-audit jobs to reduce repeat install time.
- Verification: workflow YAML parsed successfully; `python -m compileall -q backend` and `bash -n scripts/verify_all.sh` passed; the explicit regression set passed (19 tests).
- Frontend TypeScript, lint, Vitest, production build, and dependency audits remain unverified locally because `npm ci` timed out in this environment. CI configuration is added but has not been run on GitHub here.


## Threat injection request-context regression fix (2026-10-19)
- Fixed `/api/inject-threat` to accept FastAPI `Request` explicitly before using `_client_ip(request)` for the observed transport peer IP. Previously, valid threat injection reached this call without a `request` parameter and returned HTTP 500.
- Regression verification: `python -m unittest test_backend_api.BackendApiTests.test_threat_injection_validates_payload_and_runs_models -q` passed (1 test). Broader `test_e2e_ip_pipeline test_e2e_pipeline_core test_backend_api` run exercised 50 tests but had this failure before the fix; rerun after fix is pending.

## Threat injection IP provenance update (2026-10-19)
- The threat-injection response now exposes `observed_source_ip` separately from the scenario's caller-supplied `attacker_ip` field.
- Risk scoring uses the transport peer address only; caller-supplied `X-Forwarded-For` remains untrusted. This prevents simulator metadata from being mistaken for the source address used in scoring.
- Added regression assertions for a claimed attacker IP and spoofed forwarded header.
- Verification: `python -m compileall -q backend` passed; `cd backend && python -m unittest test_backend_api.BackendApiTests.test_threat_injection_validates_payload_and_runs_models test_e2e_ip_pipeline test_known_bad_scoring -q` passed (8 tests).
- These tests use synthetic requests and do not establish real-world detection accuracy or production readiness.
